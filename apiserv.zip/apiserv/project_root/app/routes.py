from flask import Blueprint, request, jsonify
from project_root.app import db
from project_root.app.models import User, UserApp, UserSite, Violation

api_bp = Blueprint('api', __name__)

@api_bp.route('/')
def index():
    return jsonify({"message": "API работает. Используйте /api/users и другие эндпоинты."})

@api_bp.route('/users/<int:user_id>/violations', methods=['GET'])
def get_user_violations(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    violations = [
        {
            "id": v.id,
            "description": v.description,
            "timestamp": v.timestamp.isoformat() if v.timestamp else None
        }
        for v in user.violations
    ]
    return jsonify(violations), 200


@api_bp.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()
    username = data.get('username')
    if not username:
        return jsonify({"error": "Username is required"}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Username already exists"}), 409

    user = User(username=username)
    db.session.add(user)
    db.session.commit()
    return jsonify({"id": user.id, "username": user.username}), 201

@api_bp.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    result = [{"id": u.id, "username": u.username} for u in users]
    return jsonify(result), 200

@api_bp.route('/users/<int:user_id>/apps', methods=['POST'])
def add_user_app(user_id):
    data = request.get_json()
    pid = data.get('pid')
    if pid is None:
        return jsonify({"error": "pid is required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    app_access = UserApp(pid=pid, user=user)
    db.session.add(app_access)
    db.session.commit()
    return jsonify({"id": app_access.id, "pid": app_access.pid}), 201

@api_bp.route('/users/<int:user_id>/sites', methods=['POST'])
def add_user_site(user_id):
    data = request.get_json()
    url = data.get('url')
    if not url:
        return jsonify({"error": "url is required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    site_access = UserSite(url=url, user=user)
    db.session.add(site_access)
    db.session.commit()
    return jsonify({"id": site_access.id, "url": site_access.url}), 201

@api_bp.route('/users/<int:user_id>/apps', methods=['GET'])
def get_user_apps(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    apps = [{"id": app.id, "pid": app.pid} for app in user.apps]
    return jsonify(apps), 200

@api_bp.route('/users/<int:user_id>/sites', methods=['GET'])
def get_user_sites(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    sites = [{"id": site.id, "url": site.url} for site in user.sites]
    return jsonify(sites), 200

@api_bp.route('/violations', methods=['POST'])
def create_violation():
    data = request.get_json()
    user_id = data.get('user_id')
    description = data.get('description')

    if user_id is None or not description:
        return jsonify({"error": "user_id and description are required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    violation = Violation(user=user, description=description)
    db.session.add(violation)
    db.session.commit()
    return jsonify({"id": violation.id, "user_id": user_id, "description": description}), 201
